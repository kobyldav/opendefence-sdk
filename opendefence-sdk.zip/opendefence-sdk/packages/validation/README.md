# @opendefence/validation

Part of OpenDefence SDK. See the repository root README for architecture and scope.
